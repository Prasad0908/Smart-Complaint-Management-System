# Upgrade Summary: Smart Complaint Management (20260926135156)

- **Completed**: 2026-09-26
- **Operator**: DELL
- **Result**: Successful
- **Version control**: Unavailable; changes remain in the working directory and no commit was created.

## Upgrade Outcome

The project now targets Java 25, the latest LTS release as of 2026-09-26. JDK 25.0.2 was installed. Both Maven WAR projects use `maven.compiler.release=25` and Maven Compiler Plugin 3.14.1. The nested WAR's mismatched Maven parent reference was removed so it can build independently.

The VS Code workspace config now sets `JAVA_HOME` for the Tomcat extension to JDK 25.0.2. Tomcat was restarted on that JDK, and the rebuilt root WAR was deployed to its active webapps directory.

## Verification

| Check | Result |
| ----- | ------ |
| Root WAR `mvn clean test-compile -q` | Passed on JDK 25.0.2 |
| Nested WAR `mvn clean test-compile -q` | Passed on JDK 25.0.2 |
| Root and nested `mvn clean verify '-Djacoco.skip=false' -q` | Passed |
| Root controller class-file major version | 69 (Java 25) |
| Running Tomcat JVM | OpenJDK 25.0.2 LTS |
| `http://localhost:8080/SmartComplaintManagement/` | HTTP 200 |
| Direct dependency CVE scan | No known CVEs requiring fixes |

No test sources or Surefire reports are present in either project, so the successful Maven test lifecycles discovered zero tests. No JaCoCo plugin or coverage report is configured. The pre-upgrade baseline was skipped because JDK 17 is not installed. Maven emitted non-fatal Jansi and Guava `Unsafe` warnings on JDK 25.

## HTTP 404 Resolution

The WAR had been placed in a different Tomcat installation's `webapps` directory. The active VS Code-managed Tomcat uses a separate `CATALINA_BASE`, whose `webapps` directory initially contained only `ROOT`; consequently the `/SmartComplaintManagement` context did not exist. The rebuilt WAR was copied into the active base and Tomcat deployed it successfully. The URL above now serves the complaint system home page.

## Changes

- `pom.xml`: Java release 25 and Maven Compiler Plugin 3.14.1.
- `SmartComplaintWebApp/pom.xml`: Java release 25, Maven Compiler Plugin 3.14.1, and standalone Maven coordinates.
- `.vscode/settings.json`: Tomcat extension `JAVA_HOME` points to JDK 25.0.2.
