# Upgrade Plan: Smart Complaint Management (20260926135156)

- **Generated**: 2026-09-26 13:51:56
- **HEAD Branch**: N/A
- **HEAD Commit ID**: N/A
- **Version control notice**: No version control repository is available; upgrade changes will remain in the working directory and will not be committed.

## Available Tools

**JDKs**
- JDK 17: not available (baseline will be skipped)
- JDK 25.0.2: `C:\Users\DELL\AppData\Local\jdks\jdk-25.0.2\bin` (installed for upgrade and final validation)
- JDK 26.0.1: `C:\Program Files\Java\jdk-26.0.1` (currently on PATH)

**Build Tools**
- Maven 3.9.9: `D:\Project Practice\Smart Complaint Management System\.tools\apache-maven-3.9.9\bin`
- Maven Wrapper: not present

## Guidelines

- Upgrade the project's Java runtime and compiler target to Java 25 LTS.
- Run the plan in auto-execution mode.

> Note: You can add any specific guidelines or constraints for the upgrade process here if needed, bullet points are preferred.

## Options

- Working branch: N/A (version control unavailable)
- Run tests before and after the upgrade: true

## Upgrade Goals

- Java runtime/compiler target: 25 (latest LTS as of 2026-09-26)

## Technology Stack

| Technology/Dependency | Current | Min Compatible Version | Why Incompatible |
| --------------------- | ------- | ---------------------- | ---------------- |
| Java compiler target (root WAR) | 17 | 25 | User requested latest LTS |
| Java compiler target (nested WAR) | 1.7 | 25 | User requested latest LTS; old target is incompatible with JDK 25 |
| Maven | 3.9.9 | 3.9.9 | Compatible; no wrapper present |
| maven-compiler-plugin (both WARs) | 3.8.0 (nested) / Maven default (root) | 3.14.1 | Use a current compiler plugin compatible with modern JDKs and Java 25 release |
| Jakarta Servlet API | 6.0.0 | 6.0.0 | Java 11+ compatible; no Java 25 upgrade required |
| MySQL Connector/J | 8.4.0 | 8.4.0 | No Java 25 incompatibility found |
| JUnit | 4.11 | 4.11 | No Java 25 incompatibility known; verify tests on target JDK |
| Apache Tomcat | 10.1.59 (running) | 10.1.59 | Compatible with Java 25; running process currently uses JDK 26 |

## Derived Upgrades

- Install JDK 25 because it is the requested LTS runtime and is not currently installed.
- Set `maven.compiler.release=25` and Maven Compiler Plugin 3.14.1 in both Maven projects.
- Set `JAVA_HOME` for the VS Code-managed Tomcat process to the installed JDK 25 and restart the server for runtime validation.
- Keep Maven 3.9.9; it is already available and no wrapper is present.

## Impact Analysis

### Dependency Changes

| File | Dependency | Current | Action | Target | Reason |
|------|------------|---------|--------|--------|--------|
| `pom.xml` | `maven.compiler.source` / `maven.compiler.target` | 17 | replace | `maven.compiler.release=25` | Compile against the Java 25 API while targeting the requested LTS |
| `pom.xml` | `maven-compiler-plugin` | Maven default | add | 3.14.1 | Explicit modern compiler support for Java 25 |
| `SmartComplaintWebApp/pom.xml` | `maven.compiler.source` / `maven.compiler.target` | 1.7 | replace | `maven.compiler.release=25` | Compile against the Java 25 API while targeting the requested LTS |
| `SmartComplaintWebApp/pom.xml` | `maven-compiler-plugin` | 3.8.0 | upgrade | 3.14.1 | Modern JDK compatibility |
| `SmartComplaintWebApp/pom.xml` | Maven parent reference | `com.complaint:SmartComplaintManagement:1.0-SNAPSHOT` | remove | standalone coordinates | The root POM is a WAR at version 1.0, so the nested project references a mismatched, non-resolvable parent; make this separate WAR independently buildable for validation. |

### Source Code Changes

No Java source changes required. The source scan found no internal JDK APIs or reflective-access patterns that need remediation for Java 25.

### Configuration Changes

No application configuration changes required. Set the `JAVA_HOME` environment passed to the VS Code Tomcat extension to the installed JDK 25, then restart Tomcat; the extension supports this via `tomcat.customEnv`.

### CI/CD Changes

No CI/CD configuration files were found in the workspace.

### Risks & Warnings

- **Different current targets**: The root WAR targets Java 17 and the nested WAR targets Java 7. Both must be raised, and both artifacts must be built independently.
- **Nested Maven parent mismatch**: `SmartComplaintWebApp/pom.xml` references root version `1.0-SNAPSHOT`, while the root POM is `1.0` and packages a WAR. Remove the invalid parent link and preserve standalone GAV coordinates so the nested WAR can be validated independently.
- **Tomcat JVM selection**: The active VS Code Tomcat process currently runs on JDK 26. Set its `JAVA_HOME` to JDK 25 and restart it; confirm the running JVM version and application response after redeployment.
- **Baseline unavailable**: JDK 17 is not installed, so a Java 17 baseline build/test cannot be recorded. Final validation will run on JDK 25.

## Upgrade Steps

- Step 1: Setup Environment
  - **Rationale**: JDK 25 is required to compile and run the upgraded application.
  - **Changes to Make**: Install JDK 25 and configure the Tomcat process environment to use it. Maven 3.9.9 is already available.
  - **Verification**: `appmod-list-jdks`; JDK 25 appears with an existing installation path.

- Step 2: Setup Baseline
  - **Rationale**: Record pre-upgrade behavior when the current target JDK is available.
  - **Changes to Make**: Skip; JDK 17 and JDK 7 are unavailable, so a valid baseline cannot be run.
  - **Verification**: Record skipped baseline; no build command.

- Step 3: Upgrade Maven Java Targets
  - **Rationale**: Ensure both WAR projects target the requested Java LTS and can be built independently.
  - **Changes to Make**: Apply all Java release, compiler-plugin, and nested POM changes in Dependency Changes.
  - **Verification**: Run `mvn clean test-compile -q` in the root and nested project using JDK 25; both must compile.

- Step 4: CVE Validation & Fix
  - **Rationale**: Check direct dependencies after build configuration changes and resolve any reported vulnerabilities.
  - **Changes to Make**: Scan all direct dependencies; upgrade only dependencies with a reported available fix.
  - **Verification**: Rebuild affected project(s), then re-scan until no fixable CVEs remain.

- Step 5: Final Validation
  - **Rationale**: Confirm all targets and runtime behavior on the requested JDK.
  - **Changes to Make**: Resolve all issues found in validation; restart Tomcat with JDK 25 and redeploy the root WAR if required.
  - **Verification**: With JDK 25, run clean test-compile and clean test for both Maven projects. Confirm Tomcat reports JDK 25 and `http://localhost:8080/SmartComplaintManagement/` returns HTTP 200.
