# Smart Complaint Management System

A Java web application designed to manage customer or employee complaints in a simple, transparent, and efficient way. It allows users to register, submit complaints, track their status, and lets administrators review, update, and resolve issues.

## Project Overview

The Smart Complaint Management System is built using Java Servlets, JSP, MySQL, and Maven. It is suitable for organizations that want to handle complaints from users in a centralized platform with a role-based workflow.

### Key Features

- User registration and login
- Complaint submission with category selection
- Complaint tracking by status
- User dashboard for viewing personal complaints
- Admin dashboard with complaint summary statistics
- Admin ability to update complaint status
- Complaint deletion support for admin
- MySQL database integration
- Clean and responsive UI using HTML, CSS, and JavaScript

## Tech Stack

- Java 25
- Jakarta Servlet API
- JSP
- Maven
- MySQL
- HTML / CSS / JavaScript
- Apache Tomcat (for deployment)

## System Workflow

### User Role
- Sign up and log in
- Submit a complaint with title, category, and description
- View complaint history and current status
- Monitor complaint progression from pending to in progress to resolved

### Admin Role
- Log in as admin
- View all complaints from all users
- Check summary cards such as total, pending, in progress, and resolved complaints
- Update complaint status
- Delete complaints if needed

## Project Structure

```text
SmartComplaintManagement/
├── src/
│   ├── main/
│   │   ├── java/
│   │   │   └── com/complaint/
│   │   │       ├── controller/
│   │   │       ├── dao/
│   │   │       ├── model/
│   │   │       └── util/
│   │   └── webapp/
│   │       ├── admin/
│   │       ├── css/
│   │       ├── js/
│   │       ├── user/
│   │       ├── index.html
│   │       ├── login.html
│   │       └── register.html
│   └── test/
├── pom.xml
├── README.md
└── target/
```

## Database Configuration

Update your database credentials in:

`src/main/java/com/complaint/util/DBConnection.java`

Default configuration in this project:

```java
private static final String URL = "jdbc:mysql://localhost:3306/complaint_management";
private static final String USERNAME = "root";
private static final String PASSWORD = "root";
```

## Database Schema

Create the database and tables before running the project:

```sql
CREATE DATABASE complaint_management;
USE complaint_management;

CREATE TABLE users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    role VARCHAR(20) DEFAULT 'USER'
);

CREATE TABLE complaints (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    title VARCHAR(150) NOT NULL,
    category VARCHAR(50) NOT NULL,
    description TEXT NOT NULL,
    status VARCHAR(30) DEFAULT 'PENDING',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);
```

## Default Admin User

You can create an admin user manually in MySQL:

```sql
INSERT INTO users (name, email, password, role)
VALUES ('Admin', 'admin@system.com', 'admin123', 'ADMIN');
```

## Running the Project

### Prerequisites

- Java JDK 25
- Maven
- MySQL Server
- Apache Tomcat or any Java web container

### Steps

1. Create the MySQL database and tables.
2. Update database credentials in `DBConnection.java`.
3. Build the project:

```bash
mvn clean package
```

4. Deploy the generated WAR file to Tomcat or run it through your local web server.
5. Open the app in a browser using the local URL.

## Example URLs

- Home page: `http://localhost:8080/SmartComplaintManagement/`
- Login: `http://localhost:8080/SmartComplaintManagement/login.html`
- Register: `http://localhost:8080/SmartComplaintManagement/register.html`

## GitHub Repository Description

Smart Complaint Management System is a Java-based complaint tracking web application that helps users submit issues and allows administrators to monitor, update, and resolve them efficiently.

## License

This project is open for educational and personal use.

## Future Enhancements

- Email notifications
- File attachments for complaints
- Search and filter by category/status
- JWT or session-based security improvements
- Responsive redesign with modern UI frameworks
- Reporting and analytics dashboard

## Author

This project is built as a practice and learning project for Java web application development with JSP and MySQL.
