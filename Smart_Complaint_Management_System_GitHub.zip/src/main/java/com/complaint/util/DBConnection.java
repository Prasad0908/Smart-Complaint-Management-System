package com.complaint.util;
import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnection
{
    private static final String URL = "jdbc:mysql://localhost:3306/complaint_management";
    private static final String USERNAME = "root";
    private static final String PASSWORD = "root";

    public static Connection getConnection()
    {
        Connection connection=null;
        try
        {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection =DriverManager.getConnection(URL, USERNAME, PASSWORD);
            System.out.println("Database Connected Successfully");
        }
        catch (Exception e)
        {   System.out.println("Database Connection Failed");
            e.printStackTrace();
        }
        return connection;
    }

}