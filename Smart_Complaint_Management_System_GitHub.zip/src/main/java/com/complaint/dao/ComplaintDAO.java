package com.complaint.dao;

import com.complaint.model.Complaint;
import com.complaint.util.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class ComplaintDAO {
    public boolean addComplaint(Complaint complaint) {
        boolean result = false;
        String sql = "INSERT INTO complaints (user_id, title, category, description) VALUES (?, ?, ?, ?)";

        try (Connection connection = DBConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, complaint.getUserId());
            statement.setString(2, complaint.getTitle());
            statement.setString(3, complaint.getCategory());
            statement.setString(4, complaint.getDescription());

            int rows = statement.executeUpdate();
            result = rows > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    public List<Complaint> getUserComplaints(int userId) {
        List<Complaint> list = new ArrayList<>();
        String sql = "SELECT * FROM complaints WHERE user_id = ? ORDER BY id DESC";

        try (Connection connection = DBConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, userId);
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                Complaint complaint = new Complaint();
                complaint.setId(resultSet.getInt("id"));
                complaint.setUserId(resultSet.getInt("user_id"));
                complaint.setTitle(resultSet.getString("title"));
                complaint.setCategory(resultSet.getString("category"));
                complaint.setDescription(resultSet.getString("description"));
                complaint.setStatus(resultSet.getString("status"));
                complaint.setCreatedAt(resultSet.getTimestamp("created_at"));
                list.add(complaint);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public List<Complaint> getAllComplaints() {
        List<Complaint> list = new ArrayList<>();
        String sql = "SELECT complaints.*, users.name AS user_name FROM complaints JOIN users ON complaints.user_id = users.id ORDER BY complaints.id DESC";

        try (Connection connection = DBConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {
            while (resultSet.next()) {
                Complaint complaint = new Complaint();
                complaint.setId(resultSet.getInt("id"));
                complaint.setUserId(resultSet.getInt("user_id"));
                complaint.setUserName(resultSet.getString("user_name"));
                complaint.setTitle(resultSet.getString("title"));
                complaint.setCategory(resultSet.getString("category"));
                complaint.setDescription(resultSet.getString("description"));
                complaint.setStatus(resultSet.getString("status"));
                complaint.setCreatedAt(resultSet.getTimestamp("created_at"));
                list.add(complaint);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public boolean updateStatus(int id, String status) {
        boolean result = false;
        String sql = "UPDATE complaints SET status = ? WHERE id = ?";

        try (Connection connection = DBConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, status);
            statement.setInt(2, id);

            int rows = statement.executeUpdate();
            result = rows > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    public boolean deleteComplaint(int id) {
        boolean result = false;
        String sql = "DELETE FROM complaints WHERE id = ?";

        try (Connection connection = DBConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            int rows = statement.executeUpdate();
            result = rows > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    public int countByStatus(String status) {
        int count = 0;
        String sql = "SELECT COUNT(*) FROM complaints WHERE status = ?";

        try (Connection connection = DBConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, status);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                count = resultSet.getInt(1);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return count;
    }

    public int getTotalComplaints() {
        int count = 0;
        String sql = "SELECT COUNT(*) FROM complaints";

        try (Connection connection = DBConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {
            if (resultSet.next()) {
                count = resultSet.getInt(1);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return count;
    }
}