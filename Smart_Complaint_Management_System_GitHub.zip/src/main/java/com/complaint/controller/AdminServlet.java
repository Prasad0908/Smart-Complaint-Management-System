package com.complaint.controller;

import com.complaint.dao.ComplaintDAO;
import com.complaint.model.Complaint;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;

@WebServlet(urlPatterns = {"/admin", "/admin/", "/admin/dashboard", "/admin/complaints"})
public class AdminServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session == null || !isAdmin(session)) {
            response.sendRedirect(request.getContextPath() + "/login.html");
            return;
        }

        ComplaintDAO complaintDAO = new ComplaintDAO();
        String path = request.getServletPath();

        if (path.equals("/admin/dashboard")) {
            int total = complaintDAO.getTotalComplaints();
            int pending = complaintDAO.countByStatus("PENDING");
            int progress = complaintDAO.countByStatus("IN_PROGRESS");
            int resolved = complaintDAO.countByStatus("RESOLVED");

            request.setAttribute("total", total);
            request.setAttribute("pending", pending);
            request.setAttribute("progress", progress);
            request.setAttribute("resolved", resolved);
            request.getRequestDispatcher("/admin/dashboard.jsp").forward(request, response);
        } else if (path.equals("/admin") || path.equals("/admin/") || path.equals("/admin/complaints")) {
            List<Complaint> complaints = complaintDAO.getAllComplaints();
            request.setAttribute("complaints", complaints);
            request.getRequestDispatcher("/admin/complaints.jsp").forward(request, response);
        } else {
            response.sendError(HttpServletResponse.SC_NOT_FOUND);
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        HttpSession session = request.getSession(false);
        if (session == null || !isAdmin(session)) {
            response.sendRedirect(request.getContextPath() + "/login.html");
            return;
        }

        ComplaintDAO complaintDAO = new ComplaintDAO();
        String action = request.getParameter("action");
        String idParameter = request.getParameter("id");
        int id;
        try {
            id = Integer.parseInt(idParameter);
        } catch (NumberFormatException e) {
            response.sendRedirect(request.getContextPath() + "/admin/complaints");
            return;
        }

        if (action != null && action.equals("update")) {
            String status = request.getParameter("status");
            if (isValidStatus(status)) {
                complaintDAO.updateStatus(id, status);
            }
        } else if (action != null && action.equals("delete")) {
            complaintDAO.deleteComplaint(id);
        }

        response.sendRedirect(request.getContextPath() + "/admin/complaints");
    }

    private boolean isAdmin(HttpSession session) {
        Object user = session.getAttribute("user");
        return user instanceof com.complaint.model.User
                && "ADMIN".equalsIgnoreCase(((com.complaint.model.User) user).getRole());
    }

    private boolean isValidStatus(String status) {
        return "PENDING".equals(status)
                || "IN_PROGRESS".equals(status)
                || "RESOLVED".equals(status);
    }
}