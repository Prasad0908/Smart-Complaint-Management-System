package com.complaint.controller;
import com.complaint.dao.UserDAO;
import com.complaint.model.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
 
@WebServlet("/login")
public class LoginServlet extends HttpServlet
{
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		String email = request.getParameter("email");
		String password = request.getParameter("password");
		UserDAO userDAO = new UserDAO();
		User user = userDAO.loginUser(email, password);
		
		if(user != null)
		{
			HttpSession session = request.getSession();
			session.setAttribute("user", user);
			if("ADMIN".equalsIgnoreCase(user.getRole()))
				response.sendRedirect(request.getContextPath() + "/admin/dashboard");
			else
				response.sendRedirect(request.getContextPath() + "/user/dashboard");
		}
		else
		{
			response.sendRedirect(request.getContextPath() + "/login.html?error=invalid");
		}
	}
}