package com.complaint.controller;

import com.complaint.model.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet(urlPatterns = {"/user", "/user/", "/user/add", "/user/complaints"})
public class UserServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session == null) {
            response.sendRedirect(request.getContextPath() + "/login.html");
            return;
        }

        User user = (User) session.getAttribute("user");
        if (user == null) {
            response.sendRedirect(request.getContextPath() + "/login.html");
            return;
        }

        String path = request.getServletPath();
        if (path.equals("/user") || path.equals("/user/")) {
            response.sendRedirect(request.getContextPath() + "/user/dashboard");
            return;
        }

        if (path.equals("/user/add")) {
            request.getRequestDispatcher("/user/addComplaint.jsp").forward(request, response);
        } else if (path.equals("/user/complaints")) {
            response.sendRedirect(request.getContextPath() + "/complaint");
        } else {
            response.sendError(HttpServletResponse.SC_NOT_FOUND);
        }
    }
}
