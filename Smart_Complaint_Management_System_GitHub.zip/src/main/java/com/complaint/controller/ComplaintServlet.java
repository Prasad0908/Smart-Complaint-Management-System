package com.complaint.controller;

import com.complaint.dao.ComplaintDAO;
import com.complaint.model.Complaint;
import com.complaint.model.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;

@WebServlet("/complaint")
public class ComplaintServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session == null) {
            response.sendRedirect(request.getContextPath() + "/login.html");
            return;
        }

        User user = (User) session.getAttribute("user");
        if (user == null) {
            response.sendRedirect(request.getContextPath() + "/login.html");
            return;
        }

        String title = request.getParameter("title");
        String category = request.getParameter("category");
        String description = request.getParameter("description");

        Complaint complaint = new Complaint();
        complaint.setUserId(user.getId());
        complaint.setTitle(title);
        complaint.setCategory(category);
        complaint.setDescription(description);

        ComplaintDAO complaintDAO = new ComplaintDAO();
        boolean result = complaintDAO.addComplaint(complaint);
        if (result) {
            response.sendRedirect(request.getContextPath() + "/user/complaints");
        } else {
            response.getWriter().println("Complaint Not Submitted!!");
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session == null) {
            response.sendRedirect(request.getContextPath() + "/login.html");
            return;
        }

        User user = (User) session.getAttribute("user");
        if (user == null) {
            response.sendRedirect(request.getContextPath() + "/login.html");
            return;
        }

        ComplaintDAO complaintDAO = new ComplaintDAO();
        List<Complaint> complaints = complaintDAO.getUserComplaints(user.getId());
        request.setAttribute("complaints", complaints);
        request.getRequestDispatcher("/user/myComplaints.jsp").forward(request, response);
    }
}