<%-- <%@ page import="com.complaint.model.User" %>
<% 
	User user = (User) session.getAttribute("user");
	if (user == null) {
		response.sendRedirect(request.getContextPath() + "/login.html");
		return;
	}
%>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>User Dashboard - Smart Complaint System</title>
	<link rel="stylesheet" type="text/css" href="../css/style.css">
	<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="app-body">
<div class="app-container">
	<header class="app-header">
		<div class="brand">
			<i class="fa-solid fa-shield-halved"></i>
			<span>Smart Complaint System</span>
		</div>
		<nav class="nav-links">
			<a href="dashboard" class="nav-item active"><i class="fa-solid fa-house"></i> Dashboard</a>
			<a href="add" class="nav-item"><i class="fa-solid fa-plus-circle"></i> Submit Complaint</a>
			<a href="complaints" class="nav-item"><i class="fa-solid fa-list-check"></i> My Complaints</a>
			<a href="../logout" class="nav-item btn-logout"><i class="fa-solid fa-right-from-bracket"></i> Logout</a>
		</nav>
	</header>

	<main class="main-content">
		<div class="welcome-banner">
			<div class="welcome-text">
				<h1>Welcome back, <%= user.getName() %>! </h1>
				<p>Manage your complaints, track resolution status, or lodge a new issue easily.</p>
			</div>
			<div class="welcome-badge">
				<i class="fa-solid fa-user-circle"></i>
				<span>User Account</span>
			</div>
		</div>

		<div class="dash-grid">
			<div class="dash-card">
				<div class="dash-card-icon icon-blue">
					<i class="fa-solid fa-pen-to-square"></i>
				</div>
				<h3>Submit Complaint</h3>
				<p>File a new complaint with categories like Technical, Electricity, or Facilities.</p>
				<a href="add" class="btn btn-primary"><i class="fa-solid fa-arrow-right"></i> File Complaint</a>
			</div>

			<div class="dash-card">
				<div class="dash-card-icon icon-purple">
					<i class="fa-solid fa-clock-rotate-left"></i>
				</div>
				<h3>My Complaints</h3>
				<p>View all complaints you've submitted and track live admin status updates.</p>
				<a href="complaints" class="btn btn-secondary"><i class="fa-solid fa-eye"></i> View Complaints</a>
			</div>
		</div>
	</main>
</div>
</body>
</html> --%>





<%@ page import="com.complaint.model.User" %>
<%
    User user = (User) session.getAttribute("user");
    if (user == null) {
        response.sendRedirect(request.getContextPath() + "/login.html");
        return;
    }
%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>User Dashboard - Smart Complaint System</title>
    <link rel="stylesheet" type="text/css" href="../css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="app-body">
<div class="app-container">
    <header class="app-header">
        <div class="brand">
            <i class="fa-solid fa-shield-halved"></i>
            <span>Smart Complaint System</span>
        </div>
        <nav class="nav-links">
            <a href="dashboard" class="nav-item active"><i class="fa-solid fa-house"></i> Dashboard</a>
            <a href="add" class="nav-item"><i class="fa-solid fa-plus-circle"></i> Submit Complaint</a>
            <a href="complaints" class="nav-item"><i class="fa-solid fa-list-check"></i> My Complaints</a>
            <a href="../logout" class="nav-item btn-logout"><i class="fa-solid fa-right-from-bracket"></i> Logout</a>
        </nav>
    </header>

    <main class="main-content">
        <div class="welcome-banner">
            <div class="welcome-text">
                <h1>Welcome back, <%= user.getName() %>!</h1>
                <p>Manage your complaints, track resolution status, or lodge a new issue easily.</p>
            </div>
            <div class="welcome-badge">
                <i class="fa-solid fa-user-circle"></i>
                <span>User Account</span>
            </div>
        </div>

        <div class="dash-grid">
            <div class="dash-card">
                <div class="dash-card-icon icon-blue">
                    <i class="fa-solid fa-pen-to-square"></i>
                </div>
                <h3>Submit Complaint</h3>
                <p>File a new complaint and provide the details needed for quick action.</p>
                <a href="add" class="btn btn-primary"><i class="fa-solid fa-arrow-right"></i> File Complaint</a>
            </div>

            <div class="dash-card">
                <div class="dash-card-icon icon-purple">
                    <i class="fa-solid fa-clock-rotate-left"></i>
                </div>
                <h3>My Complaints</h3>
                <p>View the complaints you have submitted and track their latest status.</p>
                <a href="complaints" class="btn btn-primary"><i class="fa-solid fa-eye"></i> View Complaints</a>
            </div>
        </div>
    </main>
</div>
</body>
</html>