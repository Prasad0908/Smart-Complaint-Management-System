<%@ page import="com.complaint.model.User" %>
<%
	if (!(session.getAttribute("user") instanceof User)) {
		response.sendRedirect(request.getContextPath() + "/login.html");
		return;
	}
%>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Submit Complaint - Smart Complaint Portal</title>
	<link rel="stylesheet" type="text/css" href="../css/style.css">
	<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="app-body">
<div class="app-container">
	<header class="app-header">
		<div class="brand">
			<i class="fa-solid fa-shield-halved"></i>
			<span>Smart Complaint System</span>
		</div>
		<nav class="nav-links">
			<a href="dashboard" class="nav-item"><i class="fa-solid fa-house"></i> Dashboard</a>
			<a href="complaints" class="nav-item"><i class="fa-solid fa-list-check"></i> My Complaints</a>
			<a href="../logout" class="nav-item btn-logout"><i class="fa-solid fa-right-from-bracket"></i> Logout</a>
		</nav>
	</header>

	<main class="main-content flex-center">
		<div class="form-card">
			<div class="form-header">
				<div class="icon-circle">
					<i class="fa-solid fa-pen-to-square"></i>
				</div>
				<h2>Submit New Complaint</h2>
				<p>Provide details below to log your issue into our system</p>
			</div>

			<form action="../complaint" method="post" class="custom-form">
				<div class="form-group">
					<label><i class="fa-solid fa-heading"></i> Complaint Title</label>
					<input type="text" name="title" placeholder="Brief subject (e.g. Wi-Fi Not Working)" required>
				</div>

				<div class="form-group">
					<label><i class="fa-solid fa-tags"></i> Category</label>
					<select name="category" required>
						<option value="">Select Category</option>
						<option value="Technical">Technical Issue</option>
						<option value="Internet">Internet & Network</option>
						<option value="Infrastructure">Infrastructure & Facilities</option>
						<option value="Electricity">Electricity & Power</option>
						<option value="Cleanliness">Cleanliness & Hygiene</option>
						<option value="Other">Other Issues</option>
					</select>
				</div>

				<div class="form-group">
					<label><i class="fa-solid fa-align-left"></i> Description</label>
					<textarea name="description" placeholder="Describe your issue in detail..." required></textarea>
				</div>

				<button type="submit" class="btn btn-primary btn-block">
					<i class="fa-solid fa-paper-plane"></i> Submit Complaint
				</button>
			</form>
			
			<div class="form-footer">
				<a href="dashboard"><i class="fa-solid fa-arrow-left"></i> Back to Dashboard</a>
			</div>
		</div>
	</main>
</div>
</body>
</html>