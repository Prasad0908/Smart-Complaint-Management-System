<%@ page import="java.util.List"%>
<%@ page import="com.complaint.model.Complaint"%>
<%@ page import="com.complaint.model.User"%>
<%
	if (!(session.getAttribute("user") instanceof User)) {
		response.sendRedirect(request.getContextPath() + "/login.html");
		return;
	}
	List<Complaint> complaints = (List<Complaint>) request.getAttribute("complaints");
%>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>My Complaints - Smart Complaint Portal</title>
	<link rel="stylesheet" type="text/css" href="<%= request.getContextPath() %>/css/style.css">
	<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="app-body">
<div class="app-container">
	<header class="app-header">
		<div class="brand">
			<i class="fa-solid fa-shield-halved"></i>
			<span>Smart Complaint System</span>
		</div>
		<nav class="nav-links">
			<a href="<%= request.getContextPath() %>/user/dashboard" class="nav-item"><i class="fa-solid fa-house"></i> Dashboard</a>
			<a href="<%= request.getContextPath() %>/user/add" class="nav-item"><i class="fa-solid fa-plus-circle"></i> Submit Complaint</a>
			<a href="<%= request.getContextPath() %>/logout" class="nav-item btn-logout"><i class="fa-solid fa-right-from-bracket"></i> Logout</a>
		</nav>
	</header>

	<main class="main-content">
		<div class="page-title-box">
			<h2><i class="fa-solid fa-list-check"></i> My Submitted Complaints</h2>
			<p>Track the status and details of your reported issues</p>
		</div>

		<div class="table-card">
			<table class="custom-table">
				<thead>
					<tr>
						<th>ID</th>
						<th>Title</th>
						<th>Category</th>
						<th>Description</th>
						<th>Status</th>
						<th>Date</th>
					</tr>
				</thead>
				<tbody>
					<% if(complaints != null && !complaints.isEmpty()) {
						for(Complaint complaint : complaints) {
							String statusClass = "badge-pending";
							if("IN_PROGRESS".equalsIgnoreCase(complaint.getStatus())) statusClass = "badge-progress";
							else if("RESOLVED".equalsIgnoreCase(complaint.getStatus())) statusClass = "badge-resolved";
					%>
					<tr>
						<td>#<%=complaint.getId()%></td>
						<td class="font-semibold"><%=complaint.getTitle()%></td>
						<td><span class="category-tag"><%=complaint.getCategory()%></span></td>
						<td class="desc-cell"><%=complaint.getDescription()%></td>
						<td><span class="status-badge <%=statusClass%>"><%=complaint.getStatus() != null ? complaint.getStatus().replace("_", " ") : "PENDING"%></span></td>
						<td class="text-muted"><%=complaint.getCreatedAt() != null ? complaint.getCreatedAt().toString().substring(0, 16) : ""%></td>
					</tr>
					<%
						}
					} else {
					%>
					<tr>
						<td colspan="6" class="empty-state">
							<i class="fa-regular fa-folder-open"></i>
							<p>No complaints submitted yet.</p>
							<a href="<%= request.getContextPath() %>/user/add" class="btn btn-primary btn-sm"><i class="fa-solid fa-plus"></i> Submit First Complaint</a>
						</td>
					</tr>
					<% } %>
				</tbody>
			</table>
		</div>
	</main>
</div>
</body>
</html>