function validateRegister() {
	let name = document.getElementById("name").value.trim();
	let email = document.getElementById("email").value.trim();
	let password = document.getElementById("password").value;

	if (name.length < 3) {
		alert("Name must contain at least 3 characters.");
		return false;
	}
	if (!email.includes("@") || !email.includes(".")) {
		alert("Please enter a valid email address.");
		return false;
	}
	if (password.length < 6) {
		alert("Password must contain at least 6 characters.");
		return false;
	}
	return true;
}

// Display URL notification banners if present
document.addEventListener("DOMContentLoaded", function () {
	const params = new URLSearchParams(window.location.search);
	const authCard = document.querySelector(".auth-card");

	if (authCard) {
		if (params.get("error") === "invalid") {
			showBanner(authCard, "Invalid email or password. Please try again.", "error");
		} else if (params.get("registered") === "true") {
			showBanner(authCard, "Account registered successfully! Please sign in.", "success");
		} else if (params.get("error") === "failed") {
			showBanner(authCard, "Registration failed. Email may already be in use.", "error");
		}
	}
});

function showBanner(parent, message, type) {
	const banner = document.createElement("div");
	banner.className = `alert-banner banner-${type}`;
	banner.style.padding = "12px 16px";
	banner.style.marginBottom = "20px";
	banner.style.borderRadius = "8px";
	banner.style.fontSize = "0.9rem";
	banner.style.fontWeight = "600";
	banner.style.textAlign = "center";

	if (type === "error") {
		banner.style.backgroundColor = "#ffe4e6";
		banner.style.color = "#e11d48";
		banner.style.border = "1px solid #fecdd3";
	} else {
		banner.style.backgroundColor = "#d1fae5";
		banner.style.color = "#059669";
		banner.style.border = "1px solid #a7f3d0";
	}

	banner.textContent = message;
	parent.insertBefore(banner, parent.querySelector("form"));
}