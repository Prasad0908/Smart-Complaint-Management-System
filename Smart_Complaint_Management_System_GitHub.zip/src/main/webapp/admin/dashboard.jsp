<%@ page import="com.complaint.model.User" %>
<%
	if (!(session.getAttribute("user") instanceof User)
			|| !"ADMIN".equalsIgnoreCase(((User) session.getAttribute("user")).getRole())) {
		response.sendRedirect(request.getContextPath() + "/login.html");
		return;
	}
%>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Admin Dashboard - Smart Complaint System</title>
	<link rel="stylesheet" type="text/css" href="../css/style.css">
	<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="app-body">
<div class="app-container">
	<header class="app-header admin-header">
		<div class="brand">
			<i class="fa-solid fa-user-shield"></i>
			<span>Smart Complaint System (Admin)</span>
		</div>
		<nav class="nav-links">
			<a href="dashboard" class="nav-item active"><i class="fa-solid fa-chart-line"></i> Dashboard</a>
			<a href="complaints" class="nav-item"><i class="fa-solid fa-tasks"></i> All Complaints</a>
			<a href="../logout" class="nav-item btn-logout"><i class="fa-solid fa-right-from-bracket"></i> Logout</a>
		</nav>
	</header>

	<main class="main-content">
		<div class="welcome-banner admin-banner">
			<div class="welcome-text">
				<h1>System Overview 📊</h1>
				<p>Monitor metrics, review active issues, and resolve complaints across all categories.</p>
			</div>
			<a href="complaints" class="btn btn-light"><i class="fa-solid fa-list-check"></i> Manage Complaints</a>
		</div>

		<div class="stats-grid">
			<div class="stat-card">
				<div class="stat-icon icon-total">
					<i class="fa-solid fa-folder-open"></i>
				</div>
				<div class="stat-info">
					<span class="stat-label">Total Complaints</span>
					<h2 class="stat-value">${total != null ? total : 0}</h2>
				</div>
			</div>

			<div class="stat-card">
				<div class="stat-icon icon-pending">
					<i class="fa-solid fa-hourglass-half"></i>
				</div>
				<div class="stat-info">
					<span class="stat-label">Pending</span>
					<h2 class="stat-value text-amber">${pending != null ? pending : 0}</h2>
				</div>
			</div>

			<div class="stat-card">
				<div class="stat-icon icon-progress">
					<i class="fa-solid fa-spinner"></i>
				</div>
				<div class="stat-info">
					<span class="stat-label">In Progress</span>
					<h2 class="stat-value text-blue">${progress != null ? progress : 0}</h2>
				</div>
			</div>

			<div class="stat-card">
				<div class="stat-icon icon-resolved">
					<i class="fa-solid fa-circle-check"></i>
				</div>
				<div class="stat-info">
					<span class="stat-label">Resolved</span>
					<h2 class="stat-value text-emerald">${resolved != null ? resolved : 0}</h2>
				</div>
			</div>
		</div>
	</main>
</div>
</body>
</html>