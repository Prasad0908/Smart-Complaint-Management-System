<%@ page import="java.util.List"%>
<%@ page import="com.complaint.model.Complaint"%>
<%@ page import="com.complaint.model.User"%>
<%
	if (!(session.getAttribute("user") instanceof User)
			|| !"ADMIN".equalsIgnoreCase(((User) session.getAttribute("user")).getRole())) {
		response.sendRedirect(request.getContextPath() + "/login.html");
		return;
	}
	List<Complaint> complaints = (List<Complaint>) request.getAttribute("complaints");
%>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Manage Complaints - Admin Portal</title>
	<link rel="stylesheet" type="text/css" href="../css/style.css">
	<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="app-body">
<div class="app-container">
	<header class="app-header admin-header">
		<div class="brand">
			<i class="fa-solid fa-user-shield"></i>
			<span>Smart Complaint System (Admin)</span>
		</div>
		<nav class="nav-links">
			<a href="dashboard" class="nav-item"><i class="fa-solid fa-chart-line"></i> Dashboard</a>
			<a href="complaints" class="nav-item active"><i class="fa-solid fa-tasks"></i> All Complaints</a>
			<a href="../logout" class="nav-item btn-logout"><i class="fa-solid fa-right-from-bracket"></i> Logout</a>
		</nav>
	</header>

	<main class="main-content">
		<div class="page-title-box">
			<h2><i class="fa-solid fa-sliders"></i> System Complaints Management</h2>
			<p>Review, update statuses, or resolve user reported grievances</p>
		</div>

		<div class="table-card">
			<table class="custom-table">
				<thead>
					<tr>
						<th>ID</th>
						<th>User</th>
						<th>Title</th>
						<th>Category</th>
						<th>Description</th>
						<th>Status</th>
						<th>Action</th>
					</tr>
				</thead>
				<tbody>
					<%
						if(complaints != null && !complaints.isEmpty()) {
							for(Complaint complaint : complaints) {
								String currentStatus = complaint.getStatus() != null ? complaint.getStatus() : "PENDING";
								String statusClass = "badge-pending";
								if("IN_PROGRESS".equalsIgnoreCase(currentStatus)) statusClass = "badge-progress";
								else if("RESOLVED".equalsIgnoreCase(currentStatus)) statusClass = "badge-resolved";
					%>
					<tr>
						<td>#<%=complaint.getId()%></td>
						<td><span class="user-chip"><i class="fa-regular fa-user"></i> <%=complaint.getUserName() != null ? complaint.getUserName() : "User #" + complaint.getUserId()%></span></td>
						<td class="font-semibold"><%=complaint.getTitle()%></td>
						<td><span class="category-tag"><%=complaint.getCategory()%></span></td>
						<td class="desc-cell"><%=complaint.getDescription()%></td>
						<td><span class="status-badge <%=statusClass%>"><%=currentStatus.replace("_", " ")%></span></td>
						<td>
							<form action="../admin" method="post" class="action-form">
								<input type="hidden" name="id" value="<%= complaint.getId()%>">
								<select name="status" class="status-select"> 
									<option value="PENDING" <%= "PENDING".equalsIgnoreCase(currentStatus) ? "selected" : "" %>>Pending</option>
									<option value="IN_PROGRESS" <%= "IN_PROGRESS".equalsIgnoreCase(currentStatus) ? "selected" : "" %>>In Progress</option>
									<option value="RESOLVED" <%= "RESOLVED".equalsIgnoreCase(currentStatus) ? "selected" : "" %>>Resolved</option>
								</select>
								<button name="action" value="update" type="submit" class="btn btn-sm btn-update" title="Update Status"><i class="fa-solid fa-check"></i></button>
								<button name="action" value="delete" type="submit" class="btn btn-sm btn-delete" title="Delete Complaint" onclick="return confirm('Are you sure you want to delete this complaint?')"><i class="fa-solid fa-trash"></i></button>
							</form>
						</td>
					</tr>
					<%
							}
						} else {
					%>
					<tr>
						<td colspan="7" class="empty-state">
							<i class="fa-regular fa-folder-open"></i>
							<p>No complaints found in system.</p>
						</td>
					</tr>
					<% } %>
				</tbody>
			</table>
		</div>
	</main>
</div>
</body>
</html>